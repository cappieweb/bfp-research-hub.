# BFP Research Hub — installatie en automatische updates

De website bevat de 43 reeds verzamelde BFP-studies, 8 onderzoekscategorieën,
zoekfunctie, sortering, statusfilters en een CSV-export. Op GitHub Pages werkt
ook de dagelijkse PubMed-update.

## Eerst bekijken (zonder hosting)

Open `site/index.html` op een computer. De 43 basisstudies staan ook ingebouwd
in de HTML, zodat het voorbeeld zelfs zonder server werkt. Klik op categorieën
of gebruik de zoekfunctie. Er worden nog geen automatische updates uitgevoerd
zolang de site alleen als lokaal bestand geopend wordt.

## Definitief online zetten — GitHub Pages

1. Maak een account op https://github.com (als je dat nog niet hebt).
2. Maak een nieuwe **publieke** repository met de naam `bfp-research-hub`, met
   de standaardbranch `main`. **Let op:** bestanden in een publieke repository
   zijn openbaar. De bundel bevat uitsluitend onderzoeksinformatie en je logo.
3. Pak de ZIP uit op je computer. Voeg **de inhoud** van de map `BFP_Research_Hub_Website`
   aan je repository toe: `site/`, `scripts/`, `.github/workflows/` en dit instructiebestand.
   De map `.github` is op sommige computers verborgen; toon verborgen bestanden
   indien nodig. Dit gaat het makkelijkst via GitHub Desktop of Git op een computer.
4. Ga in je GitHub-repository naar **Settings → Pages → Build and deployment**
   en zet **Source** op **GitHub Actions**.
5. Ga naar **Actions**, selecteer **BFP Research Hub — updates en website**, en
   kies **Run workflow** om de eerste controle en publicatie te starten.
6. Open daarna het Pages-adres dat GitHub laat zien, doorgaans:
   `https://<jouw-gebruikersnaam>.github.io/bfp-research-hub/`
   (gebruik jouw echte gebruikersnaam; dit is alleen een URL-patroon).
7. Op je iPhone: open die URL in Safari → Deel → **Zet op beginscherm**.
   Daarna heb je één vast BFP-icoon om de bibliotheek direct te openen.

## Automatisch nieuwe studies

- De workflow (`.github/workflows/update-and-publish.yml`) draait dagelijks.
- `scripts/update_studies.py` vraagt PubMed via NCBI E-utilities om nieuwe,
  recent geïndexeerde studies binnen acht BFP-categorieën.
- Nieuwe vermeldingen krijgen het label **Nieuw gevonden — nog beoordelen**.
  Er worden geen conclusies verzonnen op basis van alleen de titel.
- Dubbele vermeldingen worden op PMID, DOI of titel zoveel mogelijk voorkomen.
- De bijgewerkte lijst wordt opgeslagen in `site/data.json`, gecommit en als
  nieuwe versie van de site gepubliceerd.
- Op de website is zichtbaar wanneer PubMed het laatst succesvol is gecontroleerd.

## Grenzen en onderhoud

- De controle draait dagelijks, dus niet exact op het publicatiemoment.
- PubMed is niet volledig: sommige sportwetenschappelijke studies staan elders.
- Publicatie, indexering en daadwerkelijke beschikbaarheid kunnen verschillende
  datums hebben; oude artikelen kunnen later als nieuwe PubMed-vermelding verschijnen.
- GitHub kan geplande workflows in een inactieve publieke repository na 60 dagen
  automatisch uitschakelen en geplande runs kunnen vertraging oplopen. Controleer
  daarom soms de pagina **Actions** of de weergegeven controledatum op de site.
- Dit is een *onderzoeksindex*, geen volledige wetenschappelijke evidence review.
- De bestaande automatische ChatGPT-onderzoeksmonitor staat los van deze website;
  hij publiceert niet automatisch naar GitHub.
- Als je de oorspronkelijke 43 samenvattingen wilt corrigeren, bewerk `site/data.json`.
  Bestaande inhoud wordt door de updatescript niet overschreven.

## Technische gegevens

- Geen betaalde webserver nodig voor een gewone openbare GitHub Pages-website.
- Geen API-sleutel nodig voor de beperkte dagelijkse PubMed-zoekopdrachten.
- GitHub Actions heeft internettoegang nodig om PubMed te bereiken.
- Het script gebruikt uitsluitend de Python-standaardbibliotheek.
- `python scripts/update_studies.py --self-test` test de XML-parser offline.
- `python scripts/update_studies.py` voert één echte update uit wanneer er
  netwerktoegang is. Voer dit niet meermaals achter elkaar uit.
