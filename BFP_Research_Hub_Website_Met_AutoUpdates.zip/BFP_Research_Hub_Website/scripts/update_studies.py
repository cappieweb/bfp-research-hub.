#!/usr/bin/env python3
"""Daily PubMed monitor for the BFP Research Hub.

This script uses NCBI E-utilities (ESearch + EFetch), preserves the original
43-study curated database, adds newly indexed PubMed records as *unreviewed*,
and deduplicates by PubMed ID, DOI or normalized title.

The workflow runs on GitHub; this script never uses AI to fabricate findings.
"""
from __future__ import annotations

import datetime as dt
import json
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
DATA_PATH = BASE / "site" / "data.json"
API = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/"

# Search for military/tactical athletes, not just broad fitness news.
MILITARY = '("Military Personnel"[MeSH Terms] OR soldier*[tiab] OR infantry[tiab] OR "tactical athlete"[tiab] OR "tactical athletes"[tiab] OR "armed forces"[tiab] OR "special operations"[tiab] OR "military recruits"[tiab] OR "military personnel"[tiab])'
TOPICS = {
    "01": '("physical fitness"[tiab] OR "physical readiness"[tiab] OR "occupational performance"[tiab] OR "fitness test"[tiab] OR "combat task"[tiab])',
    "02": '("strength training"[tiab] OR "resistance training"[tiab] OR "concurrent training"[tiab] OR "endurance training"[tiab] OR "interval training"[tiab] OR "hybrid training"[tiab])',
    "03": '("load carriage"[tiab] OR rucking[tiab] OR "loaded march"[tiab] OR "ruck march"[tiab] OR "load carrying"[tiab] OR "backpack load"[tiab])',
    "04": '("sleep deprivation"[tiab] OR "sleep quality"[tiab] OR "fatigue monitoring"[tiab] OR "recovery"[tiab] OR "training load"[tiab] OR "heart rate variability"[tiab])',
    "05": '("injury prevention"[tiab] OR "musculoskeletal injury"[tiab] OR "overuse injury"[tiab] OR "injury risk"[tiab] OR "load tolerance"[tiab])',
    "06": '("sports nutrition"[tiab] OR "energy availability"[tiab] OR "energy expenditure"[tiab] OR "protein intake"[tiab] OR carbohydrate*[tiab] OR "energy deficiency"[tiab])',
    "07": '("heat acclimation"[tiab] OR "heat stress"[tiab] OR "cold exposure"[tiab] OR "hydration"[tiab] OR "environmental stress"[tiab])',
    "08": '("cognitive performance"[tiab] OR "operational performance"[tiab] OR "shooting performance"[tiab] OR "marksmanship"[tiab] OR "sleep restriction"[tiab] OR "stress resilience"[tiab])',
}
ARTICLE_TYPES = '(journal article[pt] OR review[pt] OR systematic review[pt] OR meta-analysis[pt] OR randomized controlled trial[pt])'


def api_request(path: str, params: dict, *, mode: str = "json"):
    query = urllib.parse.urlencode(params)
    url = API + path + "?" + query
    for attempt in range(4):
        req = urllib.request.Request(url, headers={"User-Agent": "BFPResearchHub/1.0 (personal research index)", "Accept": "application/json" if mode == "json" else "application/xml"})
        try:
            with urllib.request.urlopen(req, timeout=32) as response:
                raw = response.read()
            time.sleep(.43)  # NCBI public E-utilities limit: <=3 requests/second
            return json.loads(raw) if mode == "json" else ET.fromstring(raw)
        except (urllib.error.HTTPError, urllib.error.URLError, TimeoutError, ValueError, ET.ParseError) as error:
            if attempt == 3:
                raise RuntimeError(f"NCBI update request failed after retries: {type(error).__name__}: {error}") from error
            time.sleep(2 ** attempt + 1)


def normalized_title(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", text.casefold())


def parse_record(article: ET.Element, category_id: str, current_date: str) -> dict | None:
    pmid = article.findtext("./MedlineCitation/PMID", "").strip()
    if not pmid:
        return None
    title_element = article.find("./MedlineCitation/Article/ArticleTitle")
    title = " ".join("".join(title_element.itertext()).split()) if title_element is not None else ""
    if not title:
        return None
    journal = article.findtext("./MedlineCitation/Article/Journal/Title", "")
    pub_date = article.find("./MedlineCitation/Article/Journal/JournalIssue/PubDate")
    year_text = pub_date.findtext("Year", "") if pub_date is not None else ""
    if not year_text and pub_date is not None:
        year_text = pub_date.findtext("MedlineDate", "")
    if not year_text:
        year_text = article.findtext("./MedlineCitation/Article/ArticleDate/Year", "")
    match = re.search(r"(?:19|20)\d{2}", year_text)
    year = int(match.group()) if match else None
    types = [" ".join(x.itertext()).strip() for x in article.findall("./MedlineCitation/Article/PublicationTypeList/PublicationType")]
    journal_type = next((t for t in ["Systematic Review", "Meta-Analysis", "Randomized Controlled Trial", "Clinical Trial", "Review", "Journal Article"] if t in types), "Wetenschappelijke publicatie")
    ids = article.findall("./PubmedData/ArticleIdList/ArticleId")
    doi = next(("".join(item.itertext()).strip() for item in ids if item.get("IdType", "").lower() == "doi"), "")
    return {
        "id": f"PMID-{pmid}", "pmid": pmid, "doi": doi, "cat": category_id,
        "year": year, "title": title, "type": journal_type, "journal": journal,
        "population": "Doelgroep nog verifiëren in de publicatie",
        "finding": "Nog geen gecontroleerde samenvatting beschikbaar.",
        "application": "Nog inhoudelijk beoordelen voor gebruik in BFP-coaching of posts.",
        "caveat": "Automatisch gevonden in PubMed. Relevantie, onderzoeksopzet en conclusies nog niet gecontroleerd.",
        "priority": "Nieuw", "status": "nieuw", "source": "PubMed automatisch",
        "date_added": current_date, "url": f"https://pubmed.ncbi.nlm.nih.gov/{pmid}/",
    }


def fetch_new_ids() -> dict[str, str]:
    """Return a PMID -> matching first category, capped to keep the index useful."""
    pmid_category: dict[str, str] = {}
    for cat, terms in TOPICS.items():
        params = {"db": "pubmed", "term": f"{MILITARY} AND {terms} AND {ARTICLE_TYPES}", "retmode": "json", "datetype": "edat", "reldate": "30", "sort": "pub_date", "retmax": "20", "tool": "BFPResearchHub"}
        results = api_request("esearch.fcgi", params)
        ids = results.get("esearchresult", {}).get("idlist", [])
        for pmid in ids:
            pmid_category.setdefault(str(pmid), cat)
        print(f"Category {cat}: {len(ids)} recent PubMed matches", flush=True)
    return pmid_category


def dedup_key(study: dict) -> tuple[str, str, str]:
    url = study.get("url", "")
    pmid = study.get("pmid", "") or (re.search(r"pubmed\.ncbi\.nlm\.nih\.gov/(\d+)", url).group(1) if re.search(r"pubmed\.ncbi\.nlm\.nih\.gov/(\d+)", url) else "")
    return str(pmid), study.get("doi", "").lower().strip(), normalized_title(study.get("title", ""))


def update() -> int:
    db = json.loads(DATA_PATH.read_text(encoding="utf-8"))
    present_keys = [dedup_key(s) for s in db["studies"]]
    pmid_set = {i[0] for i in present_keys if i[0]}
    doi_set = {i[1] for i in present_keys if i[1]}
    title_set = {i[2] for i in present_keys if i[2]}
    matches = fetch_new_ids()
    missing = [(pmid, category) for pmid, category in matches.items() if pmid not in pmid_set]
    now = dt.date.today().isoformat()
    added = 0
    for start in range(0, len(missing), 60):
        batch = missing[start:start+60]
        root = api_request("efetch.fcgi", {"db": "pubmed", "id": ",".join(pmid for pmid, _ in batch), "rettype": "xml", "retmode": "xml", "tool": "BFPResearchHub"}, mode="xml")
        lookup = dict(batch)
        for article in root.findall("./PubmedArticle"):
            pmid = article.findtext("./MedlineCitation/PMID", "").strip()
            study = parse_record(article, lookup.get(pmid, "01"), now)
            if not study:
                continue
            kp,kd,kt = dedup_key(study)
            if kp in pmid_set or (kd and kd in doi_set) or kt in title_set:
                continue
            db["studies"].append(study)
            if kp:pmid_set.add(kp)
            if kd:doi_set.add(kd)
            title_set.add(kt)
            added+=1
    db["last_checked"] = now
    if added:
        db["last_updated"] = now
    for category in db["categories"]:
        category["count"] = sum(s.get("cat") == category["id"] for s in db["studies"])
    DATA_PATH.write_text(json.dumps(db, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"Update success: {added} new records, {len(db['studies'])} total, checked {now}")
    return added


def self_test() -> None:
    xml = ET.fromstring('<PubmedArticle><MedlineCitation><PMID>12345678</PMID><Article><ArticleTitle>Concurrent <i>resistance</i> and endurance training in soldiers</ArticleTitle><Journal><Title>Sports Science Journal</Title><JournalIssue><PubDate><Year>2026</Year></PubDate></JournalIssue></Journal><PublicationTypeList><PublicationType>Journal Article</PublicationType></PublicationTypeList></Article></MedlineCitation><PubmedData><ArticleIdList><ArticleId IdType="doi">10.1234/example</ArticleId></ArticleIdList></PubmedData></PubmedArticle>')
    s = parse_record(xml, "02", "2026-11-25")
    assert s and s["pmid"]=="12345678" and s["year"]==2026
    assert s["title"]=="Concurrent resistance and endurance training in soldiers"
    assert s["doi"]=="10.1234/example" and s["cat"]=="02" and s["status"]=="nieuw"
    assert normalized_title("DOI-ABC") == "doiabc"
    db=json.loads(DATA_PATH.read_text(encoding="utf-8")); assert len(db['studies'])>=43
    print('Self-test passed: PubMed XML parser, metadata, initial studies count')


if __name__ == "__main__":
    if "--self-test" in sys.argv:
        self_test()
    else:
        try:
            update()
        except Exception as ex:
            print(f"ERROR: no updates written: {ex}", file=sys.stderr)
            raise
